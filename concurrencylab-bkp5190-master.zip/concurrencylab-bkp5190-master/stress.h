#ifndef STRESS_H
#define STRESS_H

void run_stress(size_t main_buffer_size, size_t secondary_buffer_size, const char* filename);

#endif // STRESS_H
