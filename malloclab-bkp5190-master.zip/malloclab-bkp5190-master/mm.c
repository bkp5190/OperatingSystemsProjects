/*
 * mm.c
 *
 * Name: Boney Patel
 *
 * For the final version of my malloc lab, I changed this block of comments from prior checkpoints because my overall design changed drastically. For starters, I changed the implicit design I found and 
 * copied from the book to an explicit free list version which helped increase my throughput. I began this design by looking over pointer lab and defining a new structure for the list itself. I also
 * added global head and tail pointers, so I am able to use the explicit list all throughout my code including the heap checker. I then created functions that could add and remove nodes to the list 
 * when a block is freed or allocated. To begin writing the add function, I drew out potential cases that could arise when trying to add to my linked list. I intially set the predecessor and successor
 * of the address given to NULL because I was having overwriting problems. Next, I check the case for when the list is empty and set both the head and tail to be the address of the new free node. The
 * second case I check is when the list is not empty and there are other nodes that need to be accounted for. In this instance, I add them to the tail of the linked list by setting the successor of the
 * old tail to the new node and the successor of the new node to the old tail. This ensures that the nodes will stay linked no matter where they are physically in memory. Finally, I set the successor of
 * the new node, which is now the tail, to be NULL in case of overwriting errors. The second function I had to add was the removal of items from my linked list. I had some idea of potential cases that
 * may arise from my experience from pointer lab. I once again drew out the list and found 4 senarios may arise. The first and most simple was to remove the final node in the list. In this case, I
 * simply reset the global head and tail to NULL. The next is removing the head node in which I simply iterate the head and remove the node from the list. Third, I realized I may have to remove
 * from the tail and I followed a similar thought process to the prior case. Finally, I accounted for the general case of removing somewhere within the list. I then looked through my existing code and
 * called the functions where they would be required (in coalesce, extend_heap, place, and free). I outline what they are used for more in depth within each function's comments. Finally, I had to change
 * my find_fit function to look through the list I created rather than the implicit list from before. In order to do that, I simply iterate through the list with a temporary pointer and retained
 * the same if statement from the prior version.
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdint.h>

#include "mm.h"
#include "memlib.h"

/*
 * If you want to enable your debugging output and heap checker code,
 * uncomment the following line. Be sure not to have debugging enabled
 * in your final submission.
 */
// #define DEBUG

#ifdef DEBUG
/* When debugging is enabled, the underlying functions get called */
#define dbg_printf(...) printf(__VA_ARGS__)
#define dbg_assert(...) assert(__VA_ARGS__)
#else
/* When debugging is disabled, no code gets generated */
#define dbg_printf(...)
#define dbg_assert(...)
#endif /* DEBUG */

/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#define memset mem_memset
#define memcpy mem_memcpy
#endif /* DRIVER */

/* What is the correct alignment? */
#define ALIGNMENT 16

/* Basic Constants */
#define WSIZE 8 /* Word and header/footer size (bytes) */
#define DSIZE 16 /* Double word size (bytes) */
#define CHUNKSIZE (1<<12) /* Extend heap by this amount (byte) */

static void* heap_listp;

typedef struct LinkedListNode_s {
    struct LinkedListNode_s* pred;
    struct LinkedListNode_s* succ;
} LinkedListNode;
// I created global head and tail variables to utilize all throughout my code for the linked list rather than re-declaring them every single time.
static LinkedListNode* head;
static LinkedListNode* tail;

/* Explicit Free List Functions */

/* Add Block Function */
// This function adds a block of free memory to my explicit free list. It first checks the case if the list is entirely empty and sets the global tail and head variables I created to point to the added
// block. Additionally, I was told by a TA to cast the bp pointer that is passed through to make sure the list is stored within the free payload, so it does not take up more space. I also check the second
// case where I am adding to a list that already exists. I utilize LIFO ordering which I found in the book and simply add all the free blocks to the tail. I have to update the successor and predecessor 
// accordingly.
void add_block(LinkedListNode *bp) {
	// I set them to NULL because I was having trouble with overwriting in some of the trace files.
	bp->pred = NULL;
	bp->succ = NULL;
	if (head == NULL) {
		head = bp;
		tail = bp;
		bp->succ = NULL;
		bp->pred = NULL;
	}
	// I also add to the tail every time a new block is freed and added to the linked list.
	else {
		tail->succ = bp;
		bp->pred = tail;
		tail = bp;
		bp->succ = NULL;
	}
}

/* Remove Block Function */
// This function removes a block from my explicit free list when it is called in malloc. I begin by setting a startnode at the beginning of the address given. I then check all the different possible cases
// which I found 4 of. First, I check if the node I am trying to remove is the head node (followed by nothing). If this is the case, I set both the head and tail to be NULL. I then check if the node is
// the head, but there are more nodes following it. If this is the case, I set the node I am removing to NULL and update the head. The next case I check is when I am at the end of the list at the tail. I
// check if the node being removed is the last node in the list and simply remove it and update the tail (similar to the head). Finally, I check the last case, which is the general case of a node in the
// middle of the list. If this is the case, I set the successor and predecessor for the start node accordingly. I followed a similar procedure to pointer lab in updating.
void remove_block(LinkedListNode *bp) {
	// Case where remove is called on the head and it is the only node in the free list.
	if (bp == head && bp == tail) {
		tail = NULL;
		head = NULL;
	}
	// Case where remove is called on the head but there are more nodes present in the linked list afterwards.
	else if (bp == head && bp != tail) {
		bp->succ->pred = NULL;
		head = head->succ;
	}
	// Case where remove is called on the tail.
	else if (bp == tail) {
		bp->pred->succ = NULL;
		tail = tail->pred;
	}
	else{
		// General case for within the list removal.
		bp->succ->pred = bp->pred;
		bp->pred->succ = bp->succ;
	}
}

/* Macro Functions
 * These functions replace the macros found in the book. In terms of their content, it is almost identical to the code defined in the book.
 */

/* MAX macro function equivalent */
// This function is a simple calculation of the maximum of two given unsigned integers (size_t type). It returns the variable which holds the greater value.
static inline unsigned long get_max(size_t x, size_t y)
{
	if (x > y)
		return x;
	else {
		return y;
	}
}

/* PACK macro function equivalent */
// This function takes a given input size and allocate bit (either 0 or 1) and combines them to return a value that can be stored in a footer or header.
static inline unsigned long pack(size_t size, int alloc)
{
	return ((size) | (alloc));
}

/* GET macro function equivalent */
// This function checks the given input pointer, reads the word it references, and then returns it.
static inline unsigned long get_function(void* p)
{
	return (*(unsigned long *)(p));
}

/* PUT macro function equivalent */
// This function uses the given input pointer and stores val in the word. Also, this function does not return because there is no value to output.
static inline void put(void* p, unsigned long val)
{
	(*(unsigned long *)(p) = (val));
}

/* GET_SIZE macro function equivalent */
// This function takes the given input pointer and returns the size of the address from either the footer or header.
static inline unsigned long get_size(void* p)
{
	return (get_function(p) & ~0x7);
}

/* GET_ALLOC macro function equivalent */
// This function takes the given input pointer and returns the allocated bit from either the footer or header.
static inline unsigned long get_alloc(void* p)
{
	return (get_function(p) & 0x1);
}

/* HDRP macro function equivalent */
// This function takes the given input pointer, computes the header block, and returns a pointer to it.
static inline void* get_header(void* bp)
{
	return ((void *)(bp) - WSIZE);
}

/* FTRP macro function equivalent */
// This function takes the given input pointer, computes the footer block, and returns a pointer to it.
static inline void* get_footer(void* bp)
{
	return ((void *)(bp) + get_size(get_header(bp)) - DSIZE);
}

/* NEXT_BLKP macro function equivalent */
// This function takes the given input pointer, computes the next block, and returns a pointer to it.
static inline void* next_block(void* bp)
{
	return ((void *)(bp) + get_size(((void *)(bp) - WSIZE)));

}

/* PREV_BLKP macro function equivalent */
// This function takes the given input pointer, computes the previous block, and returns a pointer to it.
static inline void* prev_block(void* bp)
{
	return ((void *)(bp) - get_size(((void *)(bp) - DSIZE)));
}

/*
 * Helper Functions 
 */

/* Coalesce Function */
// This is another function from the book for coalescing, however, it was making my code unable to compile so I have it commented out until I fix it for the next checkpoint (now fixed). The additional design
// implementation I added after checkpoint 2 in order to account for the explicit free list is considering when a block that is coalesced which needs to be correctly updated in my free list. In 
// order to do this, I check the same cases as prior but call my helper remove and add functions when necessary. I only add at the end of all the cases because I update bp according to each case.
// I also only need to call add once for each case because coalesce ensures that the free blocks will be combined into one at the starting or previous block address. Additionally, I also have
// to cast the arguements as (LinkedListNode*) to fit the correct parameters for my add and remove functions (told by TA to do so).
static void *coalesce(void *bp)
{
	size_t prev_alloc = get_alloc(get_footer(prev_block(bp)));
	size_t next_alloc = get_alloc(get_header(next_block(bp)));
	size_t size = get_size(get_header(bp));
	
	if (prev_alloc && next_alloc) {
		return bp;
	}
	
	else if (prev_alloc && !next_alloc) {
		//I remove the next and current block when the previous is allocated but the next is not.
		remove_block((LinkedListNode *)(bp));
		remove_block((LinkedListNode *)next_block((bp)));
		size += get_size(get_header(next_block(bp)));
		put(get_header(bp), pack(size, 0));
		put(get_footer(bp), pack(size,0));
		}
	
	else if (!prev_alloc && next_alloc) {
		size += get_size(get_header(prev_block(bp)));
		//I remove the current and previous block when the next block is allocated but the previous is not
		remove_block((LinkedListNode *)(bp));
		remove_block((LinkedListNode *)(prev_block(bp)));
		put(get_footer(bp), pack(size, 0));
		put(get_header(prev_block(bp)), pack(size, 0));
		bp = prev_block(bp); /* Update bp */
	}
	
	else {
		//I remove all three blocks when the current, previous, and next are all free.
		remove_block((LinkedListNode *)prev_block((bp)));
		remove_block((LinkedListNode *)(bp));
		remove_block((LinkedListNode *)next_block((bp)));
		size += get_size(get_header(prev_block(bp))) + get_size(get_footer(next_block(bp)));
		put(get_header(prev_block(bp)), pack(size, 0));
		put(get_footer(next_block(bp)), pack(size, 0));
		bp = prev_block(bp); /* Update bp */
	}
	//In order to combine the blocks, I can simply call my add_block function.
	add_block((LinkedListNode *)(bp)); /* Final add block call for all cases */
	return bp;
}

/* Extend Heap Function */
// This function utilizes the previous put function to initialize the header, footer, and epilogue header which essentially extends the heap as needed in malloc. I copied
// this exact code from the book and replaced the macros. After checkpoint 2, I had to add a call to my add_block function to make sure my explicit free list is updated correctly when the 
// heap needs to be extended for a certain amount.
static void *extend_heap(size_t words)
{
	void *bp;
	size_t size;

	/* Allocate an even number of words to maintain alignment */
	size = (words % 2) ? (words+1) * WSIZE : words * WSIZE;
	if ((long)(bp = mem_sbrk(size)) == -1)
		return NULL;

	/* Initialize free block header/footer and the epilogue header */
	put(get_header(bp), pack(size, 0)); /* Free block header */
	put(get_footer(bp), pack(size, 0)); /* Free block footer */
	put(get_header(next_block(bp)), pack(0, 1)); /* New epilogue header */
	add_block((LinkedListNode *)(bp)); /* Add to explicit free list */
	/* Coalesce if the previous block was free */
	return coalesce(bp);
}

/* Find and Fit Function */
// This function finds the first available spot that can account for the given size to malloc in the heap and returns a pointer to the location. If no such location exists,
// the function simply returns NULL. I copied this exact code from the book and replaced the macros. After checkpoint 2, I had to completely rework my logic for looking through my explicit list
// instead of the implicit one from prior. I create a temporary iterator at the head of my explicit free list and check when the requested size is able to fit into any block found in my list.
// Otherwise, I have to keep iterating through until I find one and return it or simply return NULL if no such block can be found. 
static void *find_fit(size_t asize)
{
	LinkedListNode *temp = head; /* Start of the list */

	while (temp != NULL) {
		if (!get_alloc(get_header(temp)) && (asize <= get_size(get_header(temp)))) { /* Check appropriate size */
			return temp; /* Found fit */
		}
		temp = temp->succ; /* Iterate */
	}
	return NULL; /* No fit found */
}

/* Place Function */
// This function uses the input pointer to the requested block at the beginning of the free block and splits only if the size of the remainder is greater than or equal to the
// minimum block size. I copied this exact code from the book and replaced the macros.
static void place(void *bp, size_t asize)
{
	size_t csize = get_size(get_header(bp));
	if ((csize - asize) >= (2*DSIZE)) {
		// Case when requested size is unable to fit in current block
		put(get_header(bp), pack(asize, 1));
		put(get_footer(bp), pack(asize, 1));
		remove_block((LinkedListNode *)(bp));
		bp = next_block(bp);
		put(get_header(bp), pack(csize-asize, 0));
		put(get_footer(bp), pack(csize-asize, 0));
//		coalesce(bp);
		add_block((LinkedListNode *)(bp));

	}
	else {
		// Case when the requested size is able to fit into the current block
		put(get_header(bp), pack(csize, 1));
		put(get_footer(bp), pack(csize, 1));
		remove_block((LinkedListNode *)(bp)); /* Remove it from the free list because it is now allocated */
	}
}

/* rounds up to the nearest multiple of ALIGNMENT */
static size_t align(size_t x)
{
    return ALIGNMENT * ((x+ALIGNMENT-1)/ALIGNMENT);
}

/*
 * Initialize: returns false on error, true on success.
 */
// This function was taken directly from the book, I only changed the macros to functions that fit my code. I left the comments as well because they adequately explain what is going on.
bool mm_init(void)
{
	head = NULL;
	tail = NULL;
	/* Create the initial empty heap */
	if ((heap_listp = mem_sbrk(4*WSIZE)) == (void *)-1) {
		return false;
	}
	
	put(heap_listp, 0);	/* Alignment padding */ 
	put(heap_listp + (1*WSIZE), pack(DSIZE, 1)); /* Prologue header */ 
	put(heap_listp + (2*WSIZE), pack(DSIZE, 1)); /* Prologue footer */ 
	put(heap_listp + (3*WSIZE), pack(0, 1)); /* Epilogue header */ 
	heap_listp += (2*WSIZE);

	/* Extend the empty heap with a free block of CHUNKSIZE bytes */ 
	if (extend_heap(CHUNKSIZE/WSIZE) == NULL) {
		return false;
	}
	return true;
}

/*
 * malloc
 */
// This function was taken directly from the book and replaced with the correct macros for my code. I left the comments as well because they adequately explain what is going on. Fro my final design, 
// I did not have to change much for this function because it held up to my requirements for an epxlicit free list.
void* malloc(size_t size)
{
	size_t asize;
//	size_t extendsize;
	void *bp;

	/* Ignore spurious requests */
	if (size == 0)
		return NULL;

	/* Adjust block size to include overhead and alignment reqs. */
	if (size <= DSIZE)
        asize = 2*DSIZE;
    else {
    	asize = DSIZE * ((size + (DSIZE) + (DSIZE-1)) / DSIZE);
	}
	/* Search the free list for a fit */
	if ((bp = find_fit(asize)) != NULL) {
        place(bp, asize);
        return bp;
    }
    /* No fit found. Get more memory and place the block */ 
    //extendsize = get_max(asize,CHUNKSIZE);
    if ((bp = extend_heap(/*extendsize */asize/WSIZE)) == NULL)
        return NULL;
    place(bp, asize);
    return bp;
}

/*
 * free
 */
// This function was taken directly from the book as well, however, during the final checkpoint I added a call to add_block because it is the main way that my explicit free list must be updated when
// calls for freeing blocks in the heap are made.
void free(void* ptr)
{
	size_t size = get_size(get_header(ptr));
	
	put(get_header(ptr), pack(size, 0));
	put(get_footer(ptr), pack(size, 0));
	//Additionally, add the free block to my explicit list.
	add_block((LinkedListNode *)(ptr));
	coalesce(ptr);
}

/*
 * realloc
 */
// This function first checks the two cases given in the pdf for if the pointer is NULL, just malloc the given size or if the size is 0 then free the given pointer. The rest of the code checks
// the two other possible cases of the requested size being greater or less than the size we currently have. In either case, I set a temporary pointer to malloc the size and I utilize the memlib.c
// function of mem_memcpy to copy over the required information and then I simply free the pointer. After all the case check, I return NULL.
void* realloc(void* oldptr, size_t size)
{
	size_t oldsize = get_size(oldptr);

	if (oldptr == NULL){
		oldptr = malloc(size);
	}
	else if (size == 0) {
		free(oldptr);
	}
	else if (oldsize < size) {
		void* ptr = malloc(size);
		mem_memcpy(ptr, oldptr, oldsize);
		free(oldptr);
		return ptr;
	}
	else {
		oldsize = size;
		void* ptr = malloc(oldsize);
		mem_memcpy(ptr, oldptr, oldsize);
		free(oldptr);
		return ptr; 
	}
	return NULL;
}

/*
 * calloc
 * This function is not tested by mdriver, and has been implemented for you.
 */
void* calloc(size_t nmemb, size_t size)
{
    void* ptr;
    size *= nmemb;
    ptr = malloc(size);
    if (ptr) {
        memset(ptr, 0, size);
    }
    return ptr;
}

/*
 * Returns whether the pointer is in the heap.
 * May be useful for debugging.
 */
static bool in_heap(const void* p)
{
    return p <= mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Returns whether the pointer is aligned.
 * May be useful for debugging.
 */
static bool aligned(const void* p)
{
    size_t ip = (size_t) p;
    return align(ip) == ip;
}

/*
 * mm_checkheap
 */
// My heap checker begins by setting temporary variables to help for the beginning of the explicit list and the beginnning of the heap for which I can iterate through later on. I then go through my explicit
// list and print out my head node, the node currently being accessed, the predecessor node, the successor node, and finally the tail of the list. In my second while loop, I check when the size of my header
// is not equal to 0 which pretty much goes through the entire heap when I update my temporary pointer within the loop. I print out the header, footer, if the block is free, the address, and the size within
// the loop itself.

 int e_checker() {

	LinkedListNode* temp = head;

	while(temp != NULL) {
		if (!in_heap(temp)) {
			// Do the pointers in the free list point to valid free blocks?
			printf("ERROR Heap Pointer: Pointer is not in the heap\n");
			printf(" [Pred]: %p\n [Node]: %p\n [Succ]: %p\n [Head]: %p\n [Tail]: %p\n", temp->pred, temp, temp->succ, head, tail);
			return -1;
		}
			// Is the head node set correctly? (Predecessor is always NULL)
		else if (head->pred != NULL) {
			printf("ERROR Explicit List: Head is not set correctly.\n");
			printf(" [Pred]: %p\n [Node]: %p\n [Succ]: %p\n [Head]: %p\n [Tail]: %p\n", temp->pred, temp, temp->succ, head, tail);
			return -1;
		}
			// Is the tail node set correctly? (Successor is always NULL)
		else if (tail->succ != NULL) {
			printf("ERROR Explicit List: Tail is not set correctly.\n");
			printf(" [Pred]: %p\n [Node]: %p\n [Succ]: %p\n [Head]: %p\n [Tail]: %p\n", temp->pred, temp, temp->succ, head, tail);
			return -1;
		}
		else {
//			printf("No error: Explicit list is fine for the current checks.\n");
			return 0;
		}
		temp = temp->succ; /* Iterate */
	}
	printf("ERROR List Pointer: Potentially incorrect pointer to the head of the list.\n");
	printf(" [Head]: %p\n", head);
	return -1;
}

int h_checker() {

	LinkedListNode* temp2 = head;
	void* bp = heap_listp;

	while (get_size(get_header(bp))!= 0 && bp != NULL) {
		if (!aligned(bp)) {
			// Is the heap aligned correctly?
			printf("ERROR Heap Inconsistency: The Heap is not alligned\n");
			printf(" [Header]: %p\n [Address]: %p\n [Footer]: %p\n [Free]: %ld\n [Size]: %ld\n", get_header(bp), get_footer(bp), bp, get_alloc(get_header(bp)), get_size(get_header(bp)));
			return -1;
		}
		else if (get_alloc(get_header(bp)) == 0) {
			while (bp != temp2) {
				temp2 = (void *)get_function(temp2 + WSIZE);
				if (temp2 == 0) {
				//	printf("No error: All free blocks are accounted for.\n");
					return 0;
				}
				printf("ERROR Free Block: A free block in the heap is not found in the free list.\n");
				printf(" [Header]: %p\n [Address]: %p\n [Footer]: %p\n [Free]: %ld\n [Size]: %ld\n", get_header(bp), get_footer(bp), bp, get_alloc(get_header(bp)), get_size(get_header(bp)));
				return -1;
			}
		}

		else {
			return 0;
		}
	bp = next_block(bp); /* Iterate */
	}
//	printf("No error: Heap is fine for the current checks.\n");
	return 0;
}

bool mm_checkheap(int lineno)
{
#ifdef DEBUG
#endif
	if (e_checker() < 0 || h_checker() < 0) {
		return false;
	}
	else if (e_checker() == 0 && h_checker() < 0) {
		return false;
	}
	else if (e_checker() < 0 && h_checker() == 0) {
		return false;
	}
	else {
		return true;
	}
}
